import os, sqlite3, hashlib, pathlib, threading, shutil, time, zipfile, secrets, tempfile
from contextlib import closing
from datetime import datetime, timezone, timedelta
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query, Header, Response, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.background import BackgroundTask

# ---------------- 可选的账号密码配置（不填默认 admin/admin） ----------------
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASS", "admin")  # 建议在 Docker 里通过环境变量覆盖

BASE = pathlib.Path(os.getenv("DATA_DIR", "/data")).resolve()
VERS_DIR = BASE / "versions"
DB_PATH = BASE / "meta.db"

SESSION_TTL = 12 * 3600
MAX_SIZE = int(os.getenv("MAX_SIZE_MB", "2048")) * 1024 * 1024
MAX_ZIP = 1024 * 1024 * 1024
STATIC_DIR = pathlib.Path(__file__).parent / "static"

BASE.mkdir(parents=True, exist_ok=True)
VERS_DIR.mkdir(parents=True, exist_ok=True)
STATIC_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED = {
    ".md", ".json", ".html", ".htm", ".txt", ".pdf", ".xml", ".csv",
    ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".ico", ".bmp",
    ".mp4", ".webm", ".mkv", ".avi", ".mp3", ".wav", ".ogg", ".flac",
    ".zip", ".rar", ".7z", ".tar", ".gz", ".apk", ".fpk", ".exe", ".iso"
}
EDITABLE = {".md", ".json", ".html", ".htm", ".txt", ".xml", ".csv"}

MIME = {
    ".md": "text/markdown; charset=utf-8", ".json": "application/json; charset=utf-8",
    ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8",
    ".txt": "text/plain; charset=utf-8", ".xml": "text/xml; charset=utf-8",
    ".csv": "text/csv; charset=utf-8", ".svg": "image/svg+xml",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".webp": "image/webp", ".gif": "image/gif", ".ico": "image/x-icon", ".bmp": "image/bmp",
    ".mp4": "video/mp4", ".webm": "video/webm", ".mkv": "video/x-matroska", ".avi": "video/x-msvideo",
    ".mp3": "audio/mpeg", ".wav": "audio/wav", ".ogg": "audio/ogg", ".flac": "audio/flac",
    ".pdf": "application/pdf", ".zip": "application/zip", 
    ".rar": "application/x-rar-compressed", ".7z": "application/x-7z-compressed",
    ".tar": "application/x-tar", ".gz": "application/gzip",
    ".apk": "application/vnd.android.package-archive", ".iso": "application/x-iso9660-image"
}

app = FastAPI(title="Tiny File Vault")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
lock = threading.Lock()

# ---------------- 数据库管理 ----------------
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with closing(db()) as conn, conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS files(
          id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL UNIQUE,
          current_version INTEGER NOT NULL DEFAULT 1,
          is_public INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS versions(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
          version INTEGER NOT NULL, stored_name TEXT NOT NULL,
          size INTEGER NOT NULL, sha256 TEXT NOT NULL, mime TEXT NOT NULL,
          note TEXT DEFAULT '', created_at TEXT NOT NULL,
          UNIQUE(file_id, version)
        );
        CREATE TABLE IF NOT EXISTS folders(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          path TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions(
          token TEXT PRIMARY KEY, created_at TEXT NOT NULL,
          expires_at TEXT NOT NULL, ip TEXT DEFAULT '', ua TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS shares(
          token TEXT PRIMARY KEY,
          file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
          version INTEGER, expires_at TEXT, max_downloads INTEGER,
          downloads INTEGER NOT NULL DEFAULT 0, password_hash TEXT,
          created_at TEXT NOT NULL
        );
        """)
        
        # =============== 核心修复：数据库自动迁移 ===============
        try:
            conn.execute("SELECT is_public FROM files LIMIT 1")
        except sqlite3.OperationalError:
            conn.execute("ALTER TABLE files ADD COLUMN is_public INTEGER NOT NULL DEFAULT 0")
            print("[DB Migration] Added column 'is_public' to 'files' table.")

init_db()

# ---------------- 工具函数 ----------------
def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def ext_of(name: str) -> str:
    return pathlib.Path(name).suffix.lower()

def norm_path(p: str) -> str:
    p = (p or "").replace("\\", "/").strip().lstrip("/")
    parts = [x for x in p.split("/") if x and x not in (".", "..")]
    if not parts:
        raise HTTPException(400, "invalid path")
    return "/".join(parts)

def ensure_parent_folders(conn, path_str: str):
    parts = path_str.split("/")[:-1]
    current = ""
    for p in parts:
        current += p + "/"
        conn.execute("INSERT OR IGNORE INTO folders(path, created_at) VALUES(?,?)", (current, now()))

# ---------------- 认证与鉴权 ----------------
def check_auth(request: Request, authorization: str = Header(None)):
    tok = None
    if authorization and authorization.startswith("Bearer "):
        tok = authorization[7:]
    else:
        tok = request.cookies.get("fv_session")
        
    if not tok:
        raise HTTPException(401, "Unauthorized")
    with closing(db()) as conn:
        row = conn.execute("SELECT expires_at FROM sessions WHERE token=?", (tok,)).fetchone()
    if not row or row["expires_at"] < now():
        raise HTTPException(401, "Unauthorized")

@app.post("/api/login")
def login(request: Request, response: Response, user: str = Form(...), password: str = Form(...)):
    if user != ADMIN_USER or password != ADMIN_PASS:
        raise HTTPException(401, "账号或密码错误")
    
    tok = secrets.token_urlsafe(32)
    exp = (datetime.now(timezone.utc) + timedelta(seconds=SESSION_TTL)).isoformat(timespec="seconds")
    with closing(db()) as conn, conn:
        conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now(),))
        conn.execute("INSERT INTO sessions(token,created_at,expires_at,ip,ua) VALUES(?,?,?,?,?)",
                     (tok, now(), exp, request.client.host if request.client else "?", request.headers.get("user-agent", "")[:200]))
    
    is_https = request.headers.get("x-forwarded-proto") == "https" or request.url.scheme == "https"
    response.set_cookie("fv_session", tok, max_age=SESSION_TTL, httponly=True, secure=is_https, samesite="lax", path="/")
    return {"ok": True}

@app.post("/api/logout")
def logout(request: Request, response: Response, authorization: str = Header(None)):
    tok = authorization[7:] if (authorization and authorization.startswith("Bearer ")) else request.cookies.get("fv_session")
    if tok:
        with closing(db()) as conn, conn:
            conn.execute("DELETE FROM sessions WHERE token=?", (tok,))
    response.delete_cookie("fv_session", path="/")
    return {"ok": True}

# ---------------- 业务接口 ----------------
@app.get("/api/stats")
def get_stats(request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    with closing(db()) as conn:
        file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        total_size = conn.execute("SELECT SUM(v.size) FROM versions v JOIN files f ON f.id = v.file_id WHERE v.version = f.current_version").fetchone()[0] or 0
        folder_count = conn.execute("SELECT COUNT(*) FROM folders").fetchone()[0]
    return {"file_count": file_count, "total_size": total_size, "folder_count": folder_count}

@app.get("/api/browse")
def browse(request: Request, path: str = "", authorization: str = Header(None)):
    check_auth(request, authorization)
    prefix = path.strip("/")
    if prefix: prefix += "/"
    like = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"

    with closing(db()) as conn:
        rows = conn.execute(
            "SELECT f.*, (SELECT size FROM versions v WHERE v.file_id=f.id AND v.version=f.current_version) AS size "
            "FROM files f WHERE f.path LIKE ? ESCAPE '\\' ORDER BY f.path",
            (like,),
        ).fetchall()
        f_rows = conn.execute(
            "SELECT path FROM folders WHERE path LIKE ? ESCAPE '\\'", (like,)
        ).fetchall()

        dirs, files = {}, []
        for r in rows:
            rel = r["path"][len(prefix):]
            if "/" in rel:
                d = rel.split("/", 1)[0]
                dirs.setdefault(d, {"name": d, "path": prefix + d + "/", "file_count": 0})
            else:
                item = dict(r); item["name"] = rel; files.append(item)

        for r in f_rows:
            rel = r["path"][len(prefix):].strip("/")
            if rel and "/" not in rel:
                dirs.setdefault(rel, {"name": rel, "path": prefix + rel + "/", "file_count": 0})

        for d_info in dirs.values():
            d_info["file_count"] = conn.execute(
                "SELECT COUNT(*) FROM files WHERE path LIKE ?", (d_info["path"] + "%",)
            ).fetchone()[0]

    return {
        "path": prefix,
        "dirs": sorted(dirs.values(), key=lambda x: x["name"].lower()),
        "files": files,
    }

@app.post("/api/folder/create")
def create_folder(request: Request, path: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    rel = norm_path(path).strip("/") + "/"
    with lock, closing(db()) as conn, conn:
        ensure_parent_folders(conn, rel.rstrip("/"))
        conn.execute("INSERT OR IGNORE INTO folders(path, created_at) VALUES(?,?)", (rel, now()))
    return {"ok": True}

@app.post("/api/folder/delete")
def delete_folder(request: Request, path: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    prefix = norm_path(path).rstrip("/") + "/"
    like = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    with lock, closing(db()) as conn, conn:
        conn.execute("DELETE FROM folders WHERE path=?", (prefix,))
        conn.execute("DELETE FROM folders WHERE path LIKE ? ESCAPE '\\'", (like,))
        
        rows = conn.execute("SELECT id FROM files WHERE path LIKE ? ESCAPE '\\'", (like,)).fetchall()
        for r in rows:
            conn.execute("DELETE FROM files WHERE id=?", (r["id"],))
            shutil.rmtree(VERS_DIR / str(r["id"]), ignore_errors=True)
    return {"ok": True}

@app.post("/api/folder/rename")
def rename_folder(request: Request, old_path: str = Form(...), new_path: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    old_prefix = norm_path(old_path).rstrip("/") + "/"
    new_prefix = norm_path(new_path).rstrip("/") + "/"
    with lock, closing(db()) as conn, conn:
        f_rows = conn.execute("SELECT path FROM folders WHERE path LIKE ?", (old_prefix + "%",)).fetchall()
        for r in f_rows:
            new_p = r["path"].replace(old_prefix, new_prefix, 1)
            conn.execute("DELETE FROM folders WHERE path=?", (r["path"],))
            conn.execute("INSERT OR IGNORE INTO folders(path, created_at) VALUES(?,?)", (new_p, now()))
        rows = conn.execute("SELECT id, path FROM files WHERE path LIKE ?", (old_prefix + "%",)).fetchall()
        for r in rows:
            new_p = r["path"].replace(old_prefix, new_prefix, 1)
            conn.execute("UPDATE files SET path=?, updated_at=? WHERE id=?", (new_p, now(), r["id"]))
    return {"ok": True}

@app.post("/api/file/public")
def set_public(request: Request, path: str = Form(...), public: int = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    rel = norm_path(path)
    with lock, closing(db()) as conn, conn:
        row = conn.execute("SELECT id FROM files WHERE path=?", (rel,)).fetchone()
        if not row: raise HTTPException(404, "file not found")
        conn.execute("UPDATE files SET is_public=?, updated_at=? WHERE id=?", (1 if public else 0, now(), row["id"]))
    return {"ok": True}

@app.post("/api/upload")
async def upload(request: Request, file: UploadFile = File(...), path: str = Form(""), note: str = Form(""), public: int = Form(0), authorization: str = Header(None)):
    check_auth(request, authorization)
    rel = norm_path(path or file.filename or "")
    ext = ext_of(rel)
    if ext not in ALLOWED: raise HTTPException(400, "unsupported extension")
    tmp = BASE / f".upload-{time.time_ns()}.tmp"
    h = hashlib.sha256(); size = 0
    try:
        with open(tmp, "wb") as f:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_SIZE: raise HTTPException(413, "too large")
                h.update(chunk); f.write(chunk)
        sha = h.hexdigest()
        with lock, closing(db()) as conn, conn:
            ensure_parent_folders(conn, rel)
            row = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
            if row:
                file_id = row["id"]
                ver = conn.execute("SELECT MAX(version)+1 FROM versions WHERE file_id=?", (file_id,)).fetchone()[0]
            else:
                conn.execute("INSERT INTO files(path,current_version,is_public,created_at,updated_at) VALUES(?,1,?,?,?)", (rel, 1 if public else 0, now(), now()))
                file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]; ver = 1
            stored = f"{file_id}_{ver}_{sha[:8]}{ext}"
            dest_dir = VERS_DIR / str(file_id); dest_dir.mkdir(parents=True, exist_ok=True)
            os.replace(tmp, dest_dir / stored)
            conn.execute("INSERT INTO versions(file_id,version,stored_name,size,sha256,mime,note,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (file_id, ver, stored, size, sha, MIME.get(ext, "application/octet-stream"), note, now()))
            conn.execute("UPDATE files SET current_version=?, updated_at=? WHERE id=?", (ver, now(), file_id))
        return {"ok": True}
    finally:
        tmp.unlink(missing_ok=True)

def _lookup(rel: str, version: int | None):
    with closing(db()) as conn:
        f = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
        if not f: raise HTTPException(404, "file not found")
        v = version if version is not None else f["current_version"]
        vr = conn.execute("SELECT * FROM versions WHERE file_id=? AND version=?", (f["id"], v)).fetchone()
        if not vr: raise HTTPException(404, "version not found")
        p = VERS_DIR / str(f["id"]) / vr["stored_name"]
        if not p.is_file(): raise HTTPException(404, "missing")
        return p, vr

@app.post("/api/file/save")
def save_content(request: Request, path: str = Form(...), content: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    rel = norm_path(path); ext = ext_of(rel)
    if ext not in EDITABLE: raise HTTPException(400, "Unsupported")
    c_bytes = content.encode("utf-8"); sha = hashlib.sha256(c_bytes).hexdigest(); size = len(c_bytes)
    with lock, closing(db()) as conn, conn:
        ensure_parent_folders(conn, rel)
        row = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
        if row:
            file_id = row["id"]
            ver = conn.execute("SELECT MAX(version)+1 FROM versions WHERE file_id=?", (file_id,)).fetchone()[0]
        else:
            conn.execute("INSERT INTO files(path,current_version,is_public,created_at,updated_at) VALUES(?,1,0,?,?)", (rel, now(), now()))
            file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]; ver = 1
        stored = f"{file_id}_{ver}_{sha[:8]}{ext}"
        dest_dir = VERS_DIR / str(file_id); dest_dir.mkdir(parents=True, exist_ok=True)
        (dest_dir / stored).write_bytes(c_bytes)
        conn.execute("INSERT INTO versions(file_id,version,stored_name,size,sha256,mime,note,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (file_id, ver, stored, size, sha, MIME.get(ext, "text/plain; charset=utf-8"), "在线编辑", now()))
        conn.execute("UPDATE files SET current_version=?, updated_at=? WHERE id=?", (ver, now(), file_id))
    return {"ok": True}

@app.post("/api/file/rename")
def rename_file(request: Request, old_path: str = Form(...), new_path: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    old_rel = norm_path(old_path); new_rel = norm_path(new_path)
    with lock, closing(db()) as conn, conn:
        row = conn.execute("SELECT * FROM files WHERE path=?", (old_rel,)).fetchone()
        if not row: raise HTTPException(404, "File not found")
        try:
            conn.execute("UPDATE files SET path=?, updated_at=? WHERE id=?", (new_rel, now(), row["id"]))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "目标路径已存在")
    return {"ok": True}

@app.get("/api/files/{file_id}/versions")
def list_versions(file_id: int, request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    with closing(db()) as conn:
        f = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
        if not f: raise HTTPException(404, "file not found")
        vs = conn.execute("SELECT * FROM versions WHERE file_id=? ORDER BY version DESC", (file_id,)).fetchall()
    return {"file": dict(f), "versions": [dict(v) for v in vs]}

@app.post("/api/files/{file_id}/rollback/{version}")
def rollback(file_id: int, version: int, request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    with lock, closing(db()) as conn, conn:
        vr = conn.execute("SELECT 1 FROM versions WHERE file_id=? AND version=?", (file_id, version)).fetchone()
        if not vr: raise HTTPException(404, "version not found")
        conn.execute("UPDATE files SET current_version=?, updated_at=? WHERE id=?", (version, now(), file_id))
    return {"ok": True}

@app.delete("/api/files/{file_id}")
def delete_file(file_id: int, request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    with lock, closing(db()) as conn, conn:
        conn.execute("DELETE FROM files WHERE id=?", (file_id,))
    shutil.rmtree(VERS_DIR / str(file_id), ignore_errors=True)
    return {"ok": True}

@app.delete("/api/files/{file_id}/versions/{version}")
def delete_version(file_id: int, version: int, request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    stored = None
    with lock, closing(db()) as conn, conn:
        f = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
        if not f: raise HTTPException(404, "file not found")
        vr = conn.execute("SELECT stored_name FROM versions WHERE file_id=? AND version=?", (file_id, version)).fetchone()
        if vr: stored = vr["stored_name"]
        remaining = conn.execute("SELECT COUNT(*) FROM versions WHERE file_id=? AND version<>?", (file_id, version)).fetchone()[0]
        if remaining == 0:
            conn.execute("DELETE FROM files WHERE id=?", (file_id,))
        else:
            conn.execute("DELETE FROM versions WHERE file_id=? AND version=?", (file_id, version))
            if f["current_version"] == version:
                maxv = conn.execute("SELECT MAX(version) FROM versions WHERE file_id=?", (file_id,)).fetchone()[0]
                conn.execute("UPDATE files SET current_version=? WHERE id=?", (maxv, file_id))
    if remaining == 0:
        shutil.rmtree(VERS_DIR / str(file_id), ignore_errors=True)
    elif stored:
        (VERS_DIR / str(file_id) / stored).unlink(missing_ok=True)
    return {"ok": True}

@app.post("/api/download_zip")
def download_zip(request: Request, paths: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    path_list = [norm_path(p) for p in paths.split(",") if p]
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip", dir=str(BASE))
    tmp.close()
    try:
        total = 0
        with zipfile.ZipFile(tmp.name, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            with closing(db()) as conn:
                for rel in path_list:
                    f = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
                    if not f: continue
                    vr = conn.execute("SELECT * FROM versions WHERE file_id=? AND version=?", (f["id"], f["current_version"])).fetchone()
                    if not vr: continue
                    p = VERS_DIR / str(f["id"]) / vr["stored_name"]
                    if p.is_file():
                        total += vr["size"]
                        if total > MAX_ZIP:
                            raise HTTPException(413, "打包内容超过限制")
                        zf.write(p, arcname=rel)
    except Exception:
        pathlib.Path(tmp.name).unlink(missing_ok=True)
        raise
    return FileResponse(tmp.name, media_type="application/zip", filename="files.zip", background=BackgroundTask(lambda: pathlib.Path(tmp.name).unlink(missing_ok=True)))

@app.post("/api/batch/delete")
def batch_delete(request: Request, paths: str = Form(...), authorization: str = Header(None)):
    check_auth(request, authorization)
    path_list = [norm_path(p) for p in paths.split(",") if p]
    with lock, closing(db()) as conn, conn:
        for rel in path_list:
            row = conn.execute("SELECT id FROM files WHERE path=?", (rel,)).fetchone()
            if row:
                conn.execute("DELETE FROM files WHERE id=?", (row["id"],))
                shutil.rmtree(VERS_DIR / str(row["id"]), ignore_errors=True)
            
            prefix = rel.rstrip("/") + "/"
            like = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            
            conn.execute("DELETE FROM folders WHERE path=?", (prefix,))
            conn.execute("DELETE FROM folders WHERE path LIKE ? ESCAPE '\\'", (like,))
            
            folder_files = conn.execute("SELECT id FROM files WHERE path LIKE ? ESCAPE '\\'", (like,)).fetchall()
            for f in folder_files:
                conn.execute("DELETE FROM files WHERE id=?", (f["id"],))
                shutil.rmtree(VERS_DIR / str(f["id"]), ignore_errors=True)
    return {"ok": True}

@app.get("/f/{path:path}")
def serve(path: str, request: Request, v: int | None = Query(None), authorization: str = Header(None)):
    rel = norm_path(path)
    with closing(db()) as conn:
        f = conn.execute("SELECT is_public FROM files WHERE path=?", (rel,)).fetchone()
    is_pub = bool(f and f["is_public"])
    if not is_pub:
        check_auth(request, authorization)
    p, vr = _lookup(rel, v)
    resp = FileResponse(p, media_type=vr["mime"])
    resp.headers["X-Content-Type-Options"] = "nosniff"
    if is_pub:
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Cross-Origin-Resource-Policy"] = "cross-origin"
        resp.headers["Cache-Control"] = "public, max-age=86400"
    if ext_of(path) in (".html", ".htm"):
        resp.headers["Content-Security-Policy"] = "sandbox allow-scripts allow-forms"
    return resp

@app.get("/download/{path:path}")
def download(path: str, request: Request, v: int | None = Query(None), authorization: str = Header(None)):
    check_auth(request, authorization)
    rel = norm_path(path)
    p, vr = _lookup(rel, v)
    return FileResponse(p, media_type=vr["mime"], filename=pathlib.Path(rel).name)

@app.post("/api/share/create")
def create_share(request: Request, path: str = Form(...), hours: int = Form(0), max_downloads: int = Form(0), password: str = Form(""), authorization: str = Header(None)):
    check_auth(request, authorization)
    rel = norm_path(path)
    with closing(db()) as conn:
        f = conn.execute("SELECT id FROM files WHERE path=?", (rel,)).fetchone()
    if not f: raise HTTPException(404, "file not found")
    tok = secrets.token_urlsafe(16)
    exp = (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat(timespec="seconds") if hours > 0 else None
    ph = hashlib.sha256(("fv:" + password).encode()).hexdigest() if password else None
    with closing(db()) as conn, conn:
        conn.execute("INSERT INTO shares(token,file_id,version,expires_at,max_downloads,password_hash,created_at) VALUES(?,?,?,?,?,?,?)", (tok, f["id"], None, exp, max_downloads or None, ph, now()))
    return {"url": f"/s/{tok}", "token": tok, "expires_at": exp}

@app.get("/api/share/list")
def list_shares(request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    with closing(db()) as conn:
        rows = conn.execute("SELECT s.*, f.path FROM shares s JOIN files f ON f.id=s.file_id ORDER BY s.created_at DESC").fetchall()
    return {"shares": [dict(r) for r in rows]}

@app.delete("/api/share/{token}")
def delete_share(token: str, request: Request, authorization: str = Header(None)):
    check_auth(request, authorization)
    with closing(db()) as conn, conn:
        conn.execute("DELETE FROM shares WHERE token=?", (token,))
    return {"ok": True}

@app.get("/s/{token}")
def serve_share(token: str, request: Request, pw: str = Query("")):
    with closing(db()) as conn:
        s = conn.execute("SELECT * FROM shares WHERE token=?", (token,)).fetchone()
    if not s: raise HTTPException(404, "not found")
    if s["expires_at"] and s["expires_at"] < now(): raise HTTPException(410, "链接已过期")
    if s["max_downloads"] is not None and s["downloads"] >= s["max_downloads"]: raise HTTPException(410, "达到下载上限")
    if s["password_hash"]:
        if not pw: raise HTTPException(401, "需要提取码")
        if hashlib.sha256(("fv:" + pw).encode()).hexdigest() != s["password_hash"]: raise HTTPException(403, "提取码错误")
    with closing(db()) as conn, conn:
        f = conn.execute("SELECT * FROM files WHERE id=?", (s["file_id"],)).fetchone()
        if not f: raise HTTPException(404, "file not found")
        v = s["version"] or f["current_version"]
        vr = conn.execute("SELECT * FROM versions WHERE file_id=? AND version=?", (f["id"], v)).fetchone()
        if not vr: raise HTTPException(404, "version not found")
        p = VERS_DIR / str(f["id"]) / vr["stored_name"]
        if not p.is_file(): raise HTTPException(404, "missing")
        conn.execute("UPDATE shares SET downloads=downloads+1 WHERE token=?", (token,))
    resp = FileResponse(p, media_type=vr["mime"], filename=pathlib.Path(f["path"]).name)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Content-Security-Policy"] = "sandbox"
    return resp

@app.get("/")
def index():
    # 兼容处理：优先找根目录的 index.html，其次找 static/index.html
    root_index = pathlib.Path(__file__).parent / "index.html"
    static_index = STATIC_DIR / "index.html"
    if root_index.exists():
        return FileResponse(root_index, media_type="text/html")
    return FileResponse(static_index, media_type="text/html")