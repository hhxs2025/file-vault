import os, sqlite3, hashlib, pathlib, threading, shutil, time, zipfile
from io import BytesIO
from contextlib import closing
from datetime import datetime, timezone
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query, Header, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE = pathlib.Path(os.getenv("DATA_DIR", "/data")).resolve()
VERS_DIR = BASE / "versions"
DB_PATH = BASE / "meta.db"
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASS", "admin123")
MAX_SIZE = int(os.getenv("MAX_SIZE_MB", "2048")) * 1024 * 1024
STATIC_DIR = pathlib.Path(__file__).parent / "static"

BASE.mkdir(parents=True, exist_ok=True)
VERS_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED = {".md", ".json", ".html", ".htm", ".png", ".jpg", ".jpeg",
           ".webp", ".gif", ".txt", ".pdf", ".fpk", ".apk"}
EDITABLE = {".md", ".json", ".html", ".htm", ".txt"}

MIME = {
    ".md": "text/markdown; charset=utf-8", ".json": "application/json; charset=utf-8",
    ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".webp": "image/webp", ".gif": "image/gif", ".txt": "text/plain; charset=utf-8",
    ".pdf": "application/pdf", ".fpk": "application/octet-stream",
    ".apk": "application/vnd.android.package-archive",
}

app = FastAPI(title="Tiny File Vault")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
lock = threading.Lock()

def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with closing(db()) as conn, conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS files(
          id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL UNIQUE,
          current_version INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS versions(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
          version INTEGER NOT NULL, stored_name TEXT NOT NULL,
          size INTEGER NOT NULL, sha256 TEXT NOT NULL, mime TEXT NOT NULL,
          note TEXT DEFAULT '', created_at TEXT NOT NULL,
          UNIQUE(file_id, version)
        );
        """)
init_db()

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def ext_of(name: str) -> str:
    return pathlib.Path(name).suffix.lower()

def norm_path(p: str) -> str:
    p = (p or "").replace("\\", "/").strip().lstrip("/")
    parts = [x for x in p.split("/") if x and x not in (".", "..")]
    if not parts:
        raise HTTPException(400, "invalid path")
    return "/".join(parts)

def check_auth(authorization: str = Header(None)):
    if not authorization or authorization != f"Bearer {hashlib.sha256(f'{ADMIN_USER}:{ADMIN_PASS}'.encode()).hexdigest()}":
        raise HTTPException(401, "Unauthorized")

@app.post("/api/login")
def login(user: str = Form(...), password: str = Form(...)):
    if user == ADMIN_USER and password == ADMIN_PASS:
        token = hashlib.sha256(f"{user}:{password}".encode()).hexdigest()
        return {"ok": True, "token": token}
    raise HTTPException(401, "账号或密码错误")

@app.get("/api/browse")
def browse(path: str = "", authorization: str = Header(None)):
    check_auth(authorization)
    prefix = path.strip("/")
    if prefix: prefix += "/"
    like = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    with closing(db()) as conn:
        rows = conn.execute("""
            SELECT f.*, (SELECT COUNT(*) FROM versions v WHERE v.file_id=f.id) AS version_count,
              (SELECT size FROM versions v WHERE v.file_id=f.id AND v.version=f.current_version) AS size,
              (SELECT mime FROM versions v WHERE v.file_id=f.id AND v.version=f.current_version) AS mime
            FROM files f WHERE f.path LIKE ? ESCAPE '\\' ORDER BY f.path
        """, (like,)).fetchall()
    dirs, files = {}, []
    for r in rows:
        rel = r["path"][len(prefix):]
        if "/" in rel:
            d = rel.split("/", 1)[0]
            dirs.setdefault(d, {"name": d, "path": prefix + d + "/", "file_count": 0})["file_count"] += 1
        else:
            item = dict(r); item["name"] = rel; files.append(item)
    return {"path": prefix, "dirs": sorted(dirs.values(), key=lambda x: x["name"].lower()), "files": files}

# ---------- 新增：批量下载与文件夹操作 ----------
@app.post("/api/download_zip")
def download_zip(paths: str = Form(...), authorization: str = Header(None)):
    check_auth(authorization)
    path_list = [norm_path(p) for p in paths.split(",") if p]
    mem_zip = BytesIO()
    with zipfile.ZipFile(mem_zip, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        with closing(db()) as conn:
            for rel in path_list:
                f = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
                if f:
                    vr = conn.execute("SELECT * FROM versions WHERE file_id=? AND version=?", (f["id"], f["current_version"])).fetchone()
                    if vr:
                        p = VERS_DIR / str(f["id"]) / vr["stored_name"]
                        if p.is_file(): zf.write(p, arcname=rel)
    mem_zip.seek(0)
    return Response(content=mem_zip.getvalue(), media_type="application/zip", headers={"Content-Disposition": "attachment; filename=files.zip"})

@app.post("/api/batch/delete")
def batch_delete(paths: str = Form(...), authorization: str = Header(None)):
    check_auth(authorization)
    path_list = [norm_path(p) for p in paths.split(",") if p]
    with lock, closing(db()) as conn, conn:
        for rel in path_list:
            row = conn.execute("SELECT id FROM files WHERE path=?", (rel,)).fetchone()
            if row:
                conn.execute("DELETE FROM files WHERE id=?", (row["id"],))
                shutil.rmtree(VERS_DIR / str(row["id"]), ignore_errors=True)
    return {"ok": True}

@app.post("/api/folder/delete")
def delete_folder(path: str = Form(...), authorization: str = Header(None)):
    check_auth(authorization)
    prefix = norm_path(path).rstrip("/") + "/"
    like = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    with lock, closing(db()) as conn, conn:
        rows = conn.execute("SELECT id FROM files WHERE path LIKE ? ESCAPE '\\'", (like,)).fetchall()
        for r in rows:
            conn.execute("DELETE FROM files WHERE id=?", (r["id"],))
            shutil.rmtree(VERS_DIR / str(r["id"]), ignore_errors=True)
    return {"ok": True}

@app.post("/api/folder/rename")
def rename_folder(old_path: str = Form(...), new_path: str = Form(...), authorization: str = Header(None)):
    check_auth(authorization)
    old_prefix = norm_path(old_path).rstrip("/") + "/"
    new_prefix = norm_path(new_path).rstrip("/") + "/"
    with lock, closing(db()) as conn, conn:
        rows = conn.execute("SELECT id, path FROM files WHERE path LIKE ?", (old_prefix + "%",)).fetchall()
        for r in rows:
            conn.execute("UPDATE files SET path=?, updated_at=? WHERE id=?", (r["path"].replace(old_prefix, new_prefix, 1), now(), r["id"]))
    return {"ok": True}

# ---------- 原有单文件接口保留 ----------
@app.get("/api/file/content")
def get_content(path: str, authorization: str = Header(None)):
    check_auth(authorization)
    p, _ = _lookup(norm_path(path), None)
    if ext_of(path) not in EDITABLE: raise HTTPException(400, "Not editable")
    try: return {"content": p.read_text(encoding="utf-8")}
    except: raise HTTPException(500, "Read error")

@app.post("/api/file/save")
def save_content(path: str = Form(...), content: str = Form(...), authorization: str = Header(None)):
    check_auth(authorization)
    rel = norm_path(path); ext = ext_of(rel)
    if ext not in EDITABLE: raise HTTPException(400, "Unsupported")
    c_bytes = content.encode("utf-8"); sha = hashlib.sha256(c_bytes).hexdigest(); size = len(c_bytes)
    with lock, closing(db()) as conn, conn:
        row = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
        if row: file_id = row["id"]; ver = conn.execute("SELECT MAX(version)+1 FROM versions WHERE file_id=?", (file_id,)).fetchone()[0]
        else:
            conn.execute("INSERT INTO files(path,created_at,updated_at) VALUES(?,?,?)", (rel, now(), now()))
            file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]; ver = 1
        stored = f"{file_id}_{ver}_{sha[:8]}{ext}"
        dest_dir = VERS_DIR / str(file_id); dest_dir.mkdir(parents=True, exist_ok=True)
        (dest_dir / stored).write_bytes(c_bytes)
        conn.execute("INSERT INTO versions(file_id,version,stored_name,size,sha256,mime,note,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (file_id, ver, stored, size, sha, MIME.get(ext, "text/plain; charset=utf-8"), "在线编辑", now()))
        conn.execute("UPDATE files SET current_version=?, updated_at=? WHERE id=?", (ver, now(), file_id))
    return {"ok": True}

@app.post("/api/file/rename")
def rename_file(old_path: str = Form(...), new_path: str = Form(...), authorization: str = Header(None)):
    check_auth(authorization)
    old_rel = norm_path(old_path); new_rel = norm_path(new_path)
    with lock, closing(db()) as conn, conn:
        row = conn.execute("SELECT * FROM files WHERE path=?", (old_rel,)).fetchone()
        if not row: raise HTTPException(404, "File not found")
        conn.execute("UPDATE files SET path=?, updated_at=? WHERE id=?", (new_rel, now(), row["id"]))
    return {"ok": True}

@app.get("/api/files/{file_id}/versions")
def list_versions(file_id: int, authorization: str = Header(None)):
    check_auth(authorization)
    with closing(db()) as conn:
        f = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
        vs = conn.execute("SELECT * FROM versions WHERE file_id=? ORDER BY version DESC", (file_id,)).fetchall()
    return {"file": dict(f), "versions": [dict(v) for v in vs]}

@app.post("/api/files/{file_id}/rollback/{version}")
def rollback(file_id: int, version: int, authorization: str = Header(None)):
    check_auth(authorization)
    with lock, closing(db()) as conn, conn:
        conn.execute("UPDATE files SET current_version=?, updated_at=? WHERE id=?", (version, now(), file_id))
    return {"ok": True}

@app.delete("/api/files/{file_id}")
def delete_file(file_id: int, authorization: str = Header(None)):
    check_auth(authorization)
    with lock, closing(db()) as conn, conn:
        conn.execute("DELETE FROM files WHERE id=?", (file_id,))
    shutil.rmtree(VERS_DIR / str(file_id), ignore_errors=True)
    return {"ok": True}

@app.delete("/api/files/{file_id}/versions/{version}")
def delete_version(file_id: int, version: int, authorization: str = Header(None)):
    check_auth(authorization)
    with lock, closing(db()) as conn, conn:
        f = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
        remaining = conn.execute("SELECT COUNT(*) FROM versions WHERE file_id=? AND version<>?", (file_id, version)).fetchone()[0]
        if remaining == 0: conn.execute("DELETE FROM files WHERE id=?", (file_id,))
        else:
            conn.execute("DELETE FROM versions WHERE file_id=? AND version=?", (file_id, version))
            if f["current_version"] == version:
                maxv = conn.execute("SELECT MAX(version) FROM versions WHERE file_id=?", (file_id,)).fetchone()[0]
                conn.execute("UPDATE files SET current_version=? WHERE id=?", (maxv, file_id))
    if remaining == 0: shutil.rmtree(VERS_DIR / str(file_id), ignore_errors=True)
    return {"ok": True}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...), path: str = Form(""), note: str = Form(""), authorization: str = Header(None)):
    check_auth(authorization)
    rel = norm_path(path or file.filename or "")
    ext = ext_of(rel)
    if ext not in ALLOWED: raise HTTPException(400, "unsupported extension")
    tmp = BASE / f".upload-{time.time_ns()}.tmp"
    h = hashlib.sha256(); size = 0
    try:
        with open(tmp, "wb") as f:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_SIZE: raise HTTPException(413, "too large")
                h.update(chunk); f.write(chunk)
        sha = h.hexdigest()
        with lock, closing(db()) as conn, conn:
            row = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
            if row: file_id = row["id"]; ver = conn.execute("SELECT MAX(version)+1 FROM versions WHERE file_id=?", (file_id,)).fetchone()[0]
            else:
                conn.execute("INSERT INTO files(path,created_at,updated_at) VALUES(?,?,?)", (rel, now(), now()))
                file_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]; ver = 1
            stored = f"{file_id}_{ver}_{sha[:8]}{ext}"
            dest_dir = VERS_DIR / str(file_id); dest_dir.mkdir(parents=True, exist_ok=True)
            os.replace(tmp, dest_dir / stored)
            conn.execute("INSERT INTO versions(file_id,version,stored_name,size,sha256,mime,note,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (file_id, ver, stored, size, sha, MIME.get(ext, "application/octet-stream"), note, now()))
            conn.execute("UPDATE files SET current_version=?, updated_at=? WHERE id=?", (ver, now(), file_id))
        return {"ok": True}
    finally:
        tmp.unlink(missing_ok=True)

def _lookup(rel: str, version: int | None):
    with closing(db()) as conn:
        f = conn.execute("SELECT * FROM files WHERE path=?", (rel,)).fetchone()
        if not f: raise HTTPException(404, "file not found")
        v = version if version is not None else f["current_version"]
        vr = conn.execute("SELECT * FROM versions WHERE file_id=? AND version=?", (f["id"], v)).fetchone()
        if not vr: raise HTTPException(404, "version not found")
        p = VERS_DIR / str(f["id"]) / vr["stored_name"]
        if not p.is_file(): raise HTTPException(404, "missing")
        return p, vr

@app.get("/f/{path:path}")
def serve(path: str, v: int | None = Query(None)):
    p, vr = _lookup(norm_path(path), v)
    resp = FileResponse(p, media_type=vr["mime"])
    resp.headers["X-Content-Type-Options"] = "nosniff"
    if ext_of(path) in (".html", ".htm"): resp.headers["Content-Security-Policy"] = "sandbox allow-scripts allow-forms"
    return resp

@app.get("/download/{path:path}")
def download(path: str, v: int | None = Query(None)):
    rel = norm_path(path)
    p, vr = _lookup(rel, v)
    return FileResponse(p, media_type=vr["mime"], filename=pathlib.Path(rel).name)

@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html", media_type="text/html")